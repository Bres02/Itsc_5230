Game Name: Amoeboid
Group Name: Star-Splintered Games
Group Members: Gavin Evans, Bodhi Ledbetter, Blaine Evey-Staley, Joe Calandra

Cheat Codes:

- Alt + F: Insta-transform into frog
- Alt + C: Insta-transform into chameleon
- Alt + H: Insta-transfrom into chinchilla
- Alt + W: Insta-win game

Controls: 

- Up, Down, Left, Right Arrows: Movement
- E: Object Interaction
- Q: Turn invisible (only Chameleon can do this)

The point of Amoeboid is to help the amoeba need to escape the volcanic eruption by getting 
to the ocean so it can survive. 
